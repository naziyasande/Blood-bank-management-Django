from django.shortcuts import render ,HttpResponse

# Create your views here.
def index(request):
    return render(request,'index.html')
    #return HttpResponse("This is home page")

def about(request):
    return render(request,'about.html')

def stock(request):
    return render(request,'stock.html')

def testimonial(request):
    return render(request,'testimonial.html')

