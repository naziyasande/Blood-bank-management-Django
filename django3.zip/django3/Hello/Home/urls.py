from django.contrib import admin
from django.urls import path
from Home import views

urlpatterns = [
   path('',views.index,name='Home'),
   path('about', views.about ,name='about'),
   path('stock', views.stock ,name='stock'),
   path('testimonial', views.testimonial ,name='testimonial')
]